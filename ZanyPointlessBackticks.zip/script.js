let slideindex=1;
showslides(slideindex);
function showslide() {
  let i;
  let slides=Animated.getelementsbyclassname("image");
  let dots=Animated.getelementsbyclassname("dot");
  for(i=0;i<slides.lenght;i++){
    slides[i].style.display="none";
  }
  for(i=0;i<dots.lenght;i++){
    dots[i].classname.replace("active","");
  }
  if(n>slide.length){slideindex= 1;
                    }
  if(n<1){
    slideindex=slide.length;
  }
  slides[slideindex-1].style.display="block";
  dots[slideindex-1].classname="active";
}
function plusslide(n) {showslides(slideindex=n);
  function currentslide(n) {
    showslides(slideindex=n);
    
  }
}